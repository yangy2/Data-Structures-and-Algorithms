Data Structures & Algorithms Final Project
Yilin Yang
Siddarth Rupavatharam
Peeyush Tambe

#EXECUTION INSTRUCTIONS

The code submitted was written using Python 3.

You may run a program using the example notation: 

python3 ./filename.py



The main executable files are dft.py and fft.py.
Save the dataset in a folder in the same directory as the two executables.

Program will print a menu and prompt user to make a selection regarding
dataset and problem size to operate on. For large problem sizes such as
32K, expect 15-20 minutes for DFT completion, depending on your machine.
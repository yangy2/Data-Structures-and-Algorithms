
from cmath import exp, pi
import sys
import time
import numpy as np

#Fill list with contents of external file
def readfile(numList, filepath):
    with open(filepath) as f:
        line = f.readline()
        while line:
            numList.append(float(line.strip('\n')))
            line = f.readline()

    return numList

def pickdata():

    filepath = "./Dataset/"

    print("Data Set")
    print("0. Zeros")
    print("1. Ones")
    print("2. -1 to 1")
    print("3. Cosine")

    var = int(input("Enter a Number: "))

    if   var == 1: filepath += "Ones/"
    elif var == 2: filepath += "(-1,1)/"
    elif var == 3: filepath += "Cosine/"
    else: filepath += "Zeros/"

    print("Data Size")
    print("256. 256")
    print("512. 512")
    print("1. 1k")
    print("2. 2k")
    print("4. 4k")
    print("8. 8k")
    print("16. 16k")
    print("32. 32k")
    print("64. 64k")

    var = int(input("Enter a Number: "))

    if   var == 1: filepath += "1024.txt"
    elif var == 2: filepath += "2K.txt"
    elif var == 4: filepath += "4K.txt"
    elif var == 8: filepath += "8K.txt"
    elif var == 16: filepath += "16K.txt"
    elif var == 32: filepath += "32K.txt"
    elif var == 64: filepath += "64K.txt"
    elif var == 512: filepath += "512.txt"
    else: filepath += "256.txt"

    print(filepath)
    print()

    return filepath

def fft(seq):
    global twiddle_count
    global tot_count
    global count

    N_points = len(seq)

# exit recursion based on size of input number of points

    if N_points <= 1:
        return seq, count

# seperate even and odd parts of input sequence

    even_seq = seq[0::2]
    even, count = fft(even_seq)

    odd_seq = seq[1::2]
    odd, count =  fft(odd_seq)

# calculate the twiddle factors based on sequence size

    twiddle = [exp(-2j*pi*k/N_points)*odd[k] for k in range(N_points//2)]

    for k in range(N_points//2):
        twiddle_count = twiddle_count + 1

    for k in range(N_points//2):
        tot_count = tot_count + 1


    return [even[k] + twiddle[k] for k in range(N_points//2)] + \
           [even[k] - twiddle[k] for k in range(N_points//2)], (tot_count + twiddle_count)

def idft(X):
    N = len(X)
    p = []

    for n in range(N):
        c = 0.0
        for k in range(N):
            c += X[k]*exp(2j*pi*k*n/N)
        p.append(c/N)

    return p


def main():
    global twiddle_count
    global tot_count
    global count
    twiddle_count = 0
    tot_count = 0
    count = 0

    x = []
    filepath = pickdata()
    readfile(x, filepath)
    #print(x)

    print("FFT Calculation Results:\n")
    start = time.time()
    FFT, count = fft(x)
    #FFT = np.fft.fft(x)
    end = time.time()

    #print("FFT is: ")
    #print(FFT)
    print("Execution Time: " + str(end-start) + " seconds")
    print("Total Operations: " + str(count))

    c = np.fft.ifft(FFT)
    #c = [abs(i) for i in c]
    #print(c)

main()
